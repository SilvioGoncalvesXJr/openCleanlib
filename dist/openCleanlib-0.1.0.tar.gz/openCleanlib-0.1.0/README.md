# openCleanlib

openCleanlib é uma biblioteca Python para limpeza, transformação e wrangling de dados usando OpenClean.

## Instalação

```bash
pip install openCleanlib
